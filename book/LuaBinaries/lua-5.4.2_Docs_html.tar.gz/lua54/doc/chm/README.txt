
This is Lua 5.4.2, released on 13 Nov 2020.

For installation instructions, license details, and
further information about Lua, see doc/readme.html.
